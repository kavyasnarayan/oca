package com.cg.practice.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.practice.bean.PracticeBean;
import com.cg.practice.exception.PracticeException;

public interface IPracticeService {

	String addPractice(PracticeBean practiceBean) throws PracticeException;
	PracticeBean showStudentDetails(String studentid) throws PracticeException;
	List<PracticeBean> retrieveStudentDetails() throws PracticeException;
	boolean validatePractice(PracticeBean practiceBean) throws PracticeException;
	boolean validateStudentid(String studentid) throws PracticeException;
}
