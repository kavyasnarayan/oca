package com.cg.practice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;






import com.cg.practice.bean.PracticeBean;
import com.cg.practice.dao.IPracticeDao;
import com.cg.practice.dao.PracticeDaoImpl;
import com.cg.practice.exception.PracticeException;



public class PracticeServiceImpl implements IPracticeService {
	
	@Override
	public boolean validatePractice(PracticeBean practiceBean)
			throws PracticeException {
		String errorMessage ="";
		String firstname=null;
		String lastname=null;
		String phonenumber=null;
	
		
		//validating name
		firstname=practiceBean.getFirstname();
		Pattern firstnamePattern=Pattern.compile("^[A-Z][A-Za-z]{3,10}$");
		Matcher firstnameMatcher=firstnamePattern.matcher(firstname);
		
		if (!(firstnameMatcher.matches())) {
			errorMessage += "\nStudent FirstName Should start with Capital letter and minimum 3 characters long.";
		}
		
		lastname=practiceBean.getLastname();
				Pattern lastnamePattern=Pattern.compile("^[A-Z][A-Za-z]{3,10}$");
				Matcher lastnameMatcher=lastnamePattern.matcher(lastname);
				
				if (!(lastnameMatcher.matches())) {
					errorMessage += "\nStudent LastName Should start with Capital letter and minimum 3 characters long.";
				}
		
		//validating phonenumber
		phonenumber=practiceBean.getPhonenumber();
		Pattern phonenumberPattern=Pattern.compile("[0-9]{10}");
		Matcher phonenumberMatcher=phonenumberPattern.matcher(phonenumber);
		
		if (!(phonenumberMatcher.matches())) {
			errorMessage += "\nPhonenumber should contain 10 digits";
		}
		
//		//validating mailid
//		mailid=practiceBean.getMailid();
//		Pattern mailidPattern=Pattern.compile("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$");
//		Matcher mailidMatcher=mailidPattern.matcher(mailid);
//		
//
//		if (!(mailidMatcher.matches())) {
//			errorMessage = "\nStudent Name Should start with Capital letter and minimum 3 characters long.";
//		}
		
	
		if (!errorMessage.isEmpty()) {
			throw new PracticeException(errorMessage);
		}
		
		return true;
	}
	
	@Override
	public String addPractice(PracticeBean practiceBean) throws PracticeException {
		String id = null;
		IPracticeDao practiceDao= new PracticeDaoImpl();
		id = practiceDao.addPractice(practiceBean);
		return id;
	}

	@Override
	public PracticeBean showStudentDetails(String studentid) throws PracticeException {
		
		IPracticeDao practiceDao= new PracticeDaoImpl();
		PracticeBean practiceBean= new PracticeBean();
		
		practiceBean= practiceDao.showStudentDetails(studentid);
	
		return practiceBean;
	}

	@Override
	public boolean validateStudentid(String studentid) throws PracticeException{
		
		  boolean result=false;
			Pattern studentidPattern = Pattern.compile("\\d{2}");
			Matcher studentidMatcher = studentidPattern.matcher(studentid);

			if (studentidMatcher.matches()){
			result=true;
			}
				return result;
	
		
	}

	@Override
	public List<PracticeBean> retrieveStudentDetails() throws PracticeException {
		List<PracticeBean> list=null;
		IPracticeDao impl=new PracticeDaoImpl();
		list=impl.retrieveStudentDetails();
		return list;
	}

		
	
	}

	

	