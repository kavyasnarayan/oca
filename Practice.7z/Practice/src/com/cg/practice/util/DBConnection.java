package com.cg.practice.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
	private static Connection connection;
	public static Connection getConnection() throws SQLException {
		if(connection==null){
			InputStream inputStream;
			try {
				inputStream = new FileInputStream("resources/dbpractice.properties");
				Properties properties = new Properties();
				properties.load(inputStream);
				String user=properties.getProperty("user");
				String password=properties.getProperty("password");
				String url=properties.getProperty("url");
			     inputStream.close();
				DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
				connection = DriverManager.getConnection(url,user,password);
			} catch (FileNotFoundException exception) {
				exception.printStackTrace();
				System.out.println("ERROR");
			} catch (IOException e) {
				e.printStackTrace();
			}
	
		}
		return connection;
		
	}

}
