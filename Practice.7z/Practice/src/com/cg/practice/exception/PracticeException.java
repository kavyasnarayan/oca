package com.cg.practice.exception;

public class PracticeException extends Exception{
	private static final long serialVersionUID = 1L;


	public PracticeException(String message) {
	super(message);
	} 

}
