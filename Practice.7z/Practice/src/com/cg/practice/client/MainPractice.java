package com.cg.practice.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.practice.bean.PracticeBean;
import com.cg.practice.dao.IPracticeDao;
import com.cg.practice.dao.PracticeDaoImpl;
import com.cg.practice.exception.PracticeException;
import com.cg.practice.service.IPracticeService;
import com.cg.practice.service.PracticeServiceImpl;



public class MainPractice {
	
	public static void main(String[] args) throws PracticeException {
		
	PracticeBean practiceBean=new PracticeBean();
	IPracticeDao practiceDao=new PracticeDaoImpl();
	IPracticeService practiceService=new PracticeServiceImpl();
	Scanner sc=new Scanner(System.in);
	String option="";
	

	do {
		System.out.println("Enter your choice\n");
		System.out.println("-----------------\n");
		System.out.println("1.Add Student\n");
		System.out.println("2.Show Student\n");
		System.out.println("3.View Student details\n");
		System.out.println("4.Exit\n");

		option = sc.next();
		
		switch (option) {
		case "1":
			System.out.println("Enter your fisrtname");
			String firstname=sc.next();
			practiceBean.setFirstname(firstname);
			
			System.out.println("Enter your lastname");
			String lastname=sc.next();
			practiceBean.setLastname(lastname);
			
			
			System.out.println("Enter phonenumber");
			String phonenumber=sc.next();
			practiceBean.setPhonenumber(phonenumber);
			
			System.out.println("Enter location");
			String location=sc.next();
			practiceBean.setLocation(location);
			
			System.out.println("Enter domain");
			String domain=sc.next();
			practiceBean.setDomain(domain);
			
			try {
				if(practiceService.validatePractice(practiceBean)){
					String id = practiceService.addPractice(practiceBean);
					System.out.println("Successfully added with id:"+id);
				}
				
			} catch (PracticeException e) {
				System.err.println(e.getMessage());
			}
			
			break;
			
		case "2":
			
				System.out.println("Enter rollnumber");
				String studentid = sc.next();
				practiceService=new PracticeServiceImpl();
				
				if (practiceService.validateStudentid(studentid)){
					
					practiceBean=practiceService.showStudentDetails(studentid);
					System.out.println(practiceBean.getFirstname()+"\n"
							+ practiceBean.getLastname()+"\n"
							+ practiceBean.getPhonenumber()+"\n"
							+ practiceBean.getLocation()+"\n"
							+ practiceBean.getDomain());
				}
				else{
					System.err.println("Invalid student id. enter valid one");
				}
				break;
				
		case "3":
			List<PracticeBean> list=new ArrayList<PracticeBean>();
			list=practiceService.retrieveStudentDetails();
			
			for(PracticeBean practiceBean1 : list){
				System.out.println("Studentid:"+practiceBean1.getStudentid()+"\n"
						+"Firstname:"+practiceBean1.getFirstname()+"\n"
						+"Lastname:"+practiceBean1.getLastname()+"\n"
						+"Phonenumber:"+practiceBean1.getPhonenumber()+"\n"
						+"Location:"+practiceBean1.getLocation()+"\n"
						+"Domain:"+practiceBean1.getDomain());
			
			}
			
			break;
		case "4":
			System.out.println("Exit");
			System.exit(4);
		default:
			System.out.println("Enter valid option");
			
			break;
		}
	} while (!option.equals("4"));
	sc.close();

	}
}

