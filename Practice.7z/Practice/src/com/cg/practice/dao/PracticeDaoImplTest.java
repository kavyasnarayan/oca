package com.cg.practice.dao;


import java.util.List;

import com.cg.practice.bean.PracticeBean;
import com.cg.practice.exception.PracticeException;

import junit.framework.TestCase;

public class PracticeDaoImplTest extends TestCase {
	IPracticeDao dao;
	protected void setUp() throws Exception {
		dao=new PracticeDaoImpl();
		
	}

	public void testAddPractice() {
		PracticeBean practiceBean=new PracticeBean();
		practiceBean.setFirstname("Nithya");
		practiceBean.setLastname("Shree");
		practiceBean.setPhonenumber("7410258963");
		practiceBean.setLocation("jammu");
		practiceBean.setDomain("java");
		try {
		String studentid = dao.addPractice(practiceBean);
			assertNotSame("1", studentid);
		} catch (PracticeException e) {
			fail(" exception occured "+e.getMessage());
		} 
		 
		}

	public void testShowStudentDetails() {
		 try {
             String studentid = "1";
             PracticeBean practiceBean=dao.showStudentDetails(studentid);
             assertNotNull(practiceBean);
      } catch (PracticeException e) {
             fail(" exception occured "+e.getMessage());
      }
	
	}

	public void testRetrieveStudentDetails() {
		List<PracticeBean> list;
        try {
               list = dao.retrieveStudentDetails();
        } catch (PracticeException e) {
               fail(" exception occured "+e.getMessage());
        }
        
	
	}

}
