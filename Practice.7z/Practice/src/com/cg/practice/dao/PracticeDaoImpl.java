package com.cg.practice.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;




import org.apache.log4j.Logger;

import com.cg.practice.bean.PracticeBean;
import com.cg.practice.exception.PracticeException;
import com.cg.practice.util.DBConnection;


public class PracticeDaoImpl implements IPracticeDao {
	private static final Logger LOGGER = Logger.getLogger(PracticeDaoImpl.class);

	@Override
	public String addPractice(PracticeBean practiceBean) throws PracticeException {
		
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		Statement statement=null;
		ResultSet resultSet=null;
		String id = "";
		
		try {
			LOGGER.info("GETTING DB CONNECTION");
			connection=DBConnection.getConnection();
			preparedStatement=connection.prepareStatement(QuerryMapper.INSERT_QUERY);
			
			preparedStatement.setString(1, practiceBean.getFirstname());
			preparedStatement.setString(2, practiceBean.getLastname());
			preparedStatement.setString(3, practiceBean.getPhonenumber());
			preparedStatement.setString(4, practiceBean.getLocation());
			preparedStatement.setString(5, practiceBean.getDomain());
			
			int result=preparedStatement.executeUpdate();
			
			if(result==1){
				LOGGER.warn("creating sequence");
				preparedStatement=connection.prepareStatement(QuerryMapper.PRACTICE_QUERY_SEQUENCE);
				resultSet=preparedStatement.executeQuery();
			}
			if (resultSet.next()) {
				id = resultSet.getString(1);
			}
			 else {
				System.out.println("Not done");
			}

		} catch (SQLException e) {
			LOGGER.error("SQLException");
			e.printStackTrace();
		}
		
		
		
		return id;
	}

	@Override
	public PracticeBean showStudentDetails(String studentid)
			throws PracticeException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		PracticeBean practiceBean=new PracticeBean();
		ResultSet resultSet=null;
		
		
		try {
			LOGGER.info("GETTING DB CONNECTION");
			connection=DBConnection.getConnection();
			LOGGER.info("viewing query");
			preparedStatement=connection.prepareStatement(QuerryMapper.VIEW_PRACTICE_DETAILS_QUERY);
			preparedStatement.setString(1, studentid);
			resultSet = preparedStatement.executeQuery();
			
			if(resultSet.next()) {
				
				practiceBean.setStudentid(resultSet.getString(1));
				practiceBean.setFirstname(resultSet.getString(2));
				practiceBean.setLastname(resultSet.getString(3));
				practiceBean.setPhonenumber(resultSet.getString(4));
				practiceBean.setLocation(resultSet.getString(5));
				practiceBean.setDomain(resultSet.getString(6));
		} 
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
		return practiceBean;
	}
	
	
	
	@SuppressWarnings("finally")
	@Override
	public List<PracticeBean> retrieveStudentDetails() throws PracticeException {
		Connection connection=null;
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		List<PracticeBean> list=new ArrayList<PracticeBean>();
		
		try {
			connection=DBConnection.getConnection();
			preparedStatement=connection.prepareStatement(QuerryMapper.RETRIVE_ALL_QUERY);
			resultSet=preparedStatement.executeQuery();
			
			while(resultSet.next()){
				PracticeBean practiceBean=new PracticeBean();
				practiceBean.setStudentid(resultSet.getString(1));
				practiceBean.setFirstname(resultSet.getString(2));
				practiceBean.setLastname(resultSet.getString(3));
				practiceBean.setPhonenumber(resultSet.getString(4));
				practiceBean.setLocation(resultSet.getString(5));
				practiceBean.setDomain(resultSet.getString(6));
				list.add(practiceBean);
				
			}
			
			
			
		} catch (SQLException exception) {
			throw new PracticeException(exception.getMessage());
		}finally{
			if (preparedStatement != null && connection != null) {
			try {
				preparedStatement.close();
				resultSet.close();
			} catch (SQLException exception) {
				throw new PracticeException(exception.getMessage());
			}
			
		}
		
		return list;
	}

	}
}
