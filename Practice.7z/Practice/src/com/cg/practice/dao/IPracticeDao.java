package com.cg.practice.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.practice.bean.PracticeBean;
import com.cg.practice.exception.PracticeException;

public interface IPracticeDao {
	
	String addPractice(PracticeBean practiceBean) throws PracticeException;	
    PracticeBean showStudentDetails(String studentid) throws PracticeException;
	List<PracticeBean> retrieveStudentDetails() throws PracticeException;

}
