package com.cg.practice.dao;

public class QuerryMapper {
	
	public static final String INSERT_QUERY="INSERT INTO practice VALUES(rollno_sequence.NEXTVAL,?,?,?,?,?)";
	public static final String PRACTICE_QUERY_SEQUENCE="SELECT rollno_sequence.CURRVAL FROM DUAL";
	public static final String RETRIVE_ALL_QUERY="SELECT studentid,firstname,lastname,phonenumber,location,domain FROM practice";
	public static final String VIEW_PRACTICE_DETAILS_QUERY="SELECT studentid,firstname,lastname,phonenumber,location,domain FROM practice WHERE  studentid=?";
}
